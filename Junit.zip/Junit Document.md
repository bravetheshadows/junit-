#JUnit教学分享
###软件工程课程第1小组
分享学习网址：https://www.w3cschool.cn/junit/2wjx1hvc.html

文件相关测试代码在压缩包中
##JUnit - 概述
单元测试是测试应用程序功能是否能够按需要正常运行，并且确保是在开发人员的水平上，单元测试生成图片。单元测试是一个对单一实体（类或方法）的测试。单元测试是每个软件公司提高产品质量、满足客户需求的重要环节。
	JUnit 是一个 Java 编程语言的单元自动测试框架，它可以自动运行检查自身结果并提供即时反馈。
	JUnit 促进了“先测试后编码”的理念，强调建立测试数据的一段代码，可以先测试，然后再应用。这个方法增加了程序员的产量和程序的稳定性，可以减少程序员的压力和花费在排错上的时间。

##JUnit - 环境设置
首先我们需要安装java环境，主流的java IDE里都能下载junit插件，这里我将讲eclipse和idea里如何使用junit插件。大多数eclipse里是自带junit插件的，这里去New一个 File 就能看见了。在Eclipse中开发、运行JUnit测试相当简单。因为Eclipse本身集成了JUnit相关组件，并对JUnit的运行提供了无缝的支持。idea需要从设置里的插件市场中手动搜索并下载junit插件，下载那个junit开头下载量最高的插件，下载完毕之后需要重启idea软件，最后还可以在设置里的其它设置栏里设置默认缺省版本里为junit4。具体的junit插件安装方法可能与IDE版本有关，建议大家根据实际情况进行操作。

##JUnit  的基本用法和注意事项
测试方法必须使用 @Test 修饰。
测试方法必须使用 public void 进行修饰，且不能带参数。
一般使用单元测试会新建一个 test 目录存放测试代码，在生产部署的时候只需要将 test 目录下代码删除即可。
能保证快速准确的找到问题出在哪里：

	测试代码的包应该和被测试代码包结构保持一致。  
	测试单元中的每个方法必须可以独立测试，方法间不能有任何依赖。

JUnit  的测试结果

JUnit 在一个条中显示进度。如果运行良好则是绿色；如果运行失败，则变成红色。
红色-测试失败说明：

	Failure：一般是由于测试结果和预期结果不一致引发的，表示测试的这个点发现了问题。
	error：  是由代码异常引起的，它可以产生于测试代码本身的错误，也可以是被测试代码中隐藏的 bug。     
      
###这里以项目testjunit作为演示。
JUnit  的一些常用注解

注解就好像你可以在你的代码中添加并且在方法或者类中应用的元标签。JUnit 中的这些注解为我们提供了测试方法的相关信息：哪些方法将会在测试方法前后应用，哪些方法将会在所有方法前后应用，哪些方法将会在执行中被忽略。


	@Test: 将一个普通方法修饰成一个测试方法 
	@Test(excepted=xx.class): xx.class 表示异常类，表示测试的方法抛出此异常时，认为是正常的测试通过的。 
	@Test(timeout = 毫秒数) ：测试方法执行时间是否符合预期。
	@BeforeClass：会在所有的方法执行前被执行，static方法（全局只会执行一次，而且是第一个运行）
	@AfterClass：会在所有的方法执行之后进行执行，static方法（全局只会执行一次，而且是最后一个运行）
	@Before：会在每一个测试方法被运行前执行一次
	@After：  会在每一个测试方法运行后被执行一次
	@Ignore：所修饰的测试方法会被测试运行器忽略
	@RunWith： 可以更改测试运行器 org.junit.runner.Runner
	@Parameters：参数化注解Unit 在一个条中显示进度。

                                                        
###这里将以项目junitannotation作为演示

JUnit的三大核心

1、测试类（TestCase）：一个包含一个或是多个测试的类，在Junit中就是指的是包含那些带有@Test注解的方法的类，同样也被称作“测试用例”;

2、测试集（TestSuite）：测试集是把多个相关测试归入一个组的表达方式，在Junit中，如果我们没有明确的定义一个测试集，那么Juint会自动的提供一个测试集，一个测试集一般将同一个包的测试类归入一组；

3、测试运行器（TestRunner）：执行测试集的程序。
定义说完了，还有两个好理解的定义：断言（assert）和测试（Test），加上这两个定义，从断言到测试运行器就是从“原子”到“分子”的过程，“原子”组成“分子”的，“分子”包含若干”原子“。

JUnit  的API

	JUnit 中的最重要的程序包是 junit.framework 它包含了所有的核心类。
	org.junit.Assert 类提供了一系列的编写测试的有用的声明方法。
	类里的一些重要方法：                            （只有失败的声明方法才会被记录）
	void assertEquals(boolean expected, boolean actual) 检查两个变量或者等式是否平衡
	void assertFalse(boolean condition)                 检查条件是假的
	void assertNotNull(Object object)                     检查对象不是空的    
	void assertNull(Object object)                       检查对象是空的
	void assertTrue(boolean condition)                 在没有报告的情况下使测试不通过

                                                             
###这里将以项目test1作为演示


org.junit.TestCase 类，这里面定义了运行多重测试的固定格式。

类里的一些重要方法：

	int countTestCases( )                          为被run(TestResult result) 执行的测试案例计数
	TestResult createResult( )                      创建一个默认的 TestResult 对象
	String getName( )                             获取 TestCase 的名称
	TestResult run( )                   运行这个测试的方便方法，收集由TestResult 对象产生的结果
	void run(TestResult result)                   在 TestResult 中运行测试案例并收集结果
	void setName(String name)                    设置 TestCase 的名称
	String toString( )                            返回测试案例的一个字符串表示


org.junit.TestResult 类，这里面收集所有执行测试案例的结果。它是收集参数层面的一个实例。这个实验框架区分失败和错误。失败是可以预料的并且可以通过假设来检查。错误是不可预料的问题就像 
ArrayIndexOutOfBoundsException （数组越界）
                                                                
类里的一些重要方法：    
                                                           
	void addError(Test test, Throwable t)                 在错误列表中加入一个错误                                      void addFailure(Test test, AssertionFailedError t)            在失败列表中加入一个失败
	int errorCount( )                                             获取被检测出错误的数量
	Enumeration errors( )                                        返回错误的详细信息
	int failureCount( )                                          获取被检测出的失败的数量 
	void run(TestCase test)                                     运行 TestCase
	void stop( )                                                  标明测试必须停止
	
	org.junit.TestSuite 类，这是测试的组成部分，它运行了很多的测试案例。                                                           
	void addTest(Test test)                                        在套中加入测试
	void addTestSuite(Class<? extends TestCase> testClass)        将已经给定的类中的测试加到套中                                      int countTestCases( )                                   对这个测试即将运行的测试案例进行计数
	String getName( )                                          返回套的名称
	void setName(String name)                                   设置套的名称
	void run(TestResult result)                                在 TestResult 中运行测试并收集结果
	int testCount( )                                               返回套中测试的数量
	static Test warning(String message)                       返回会失败的测试并且记录警告信息

                                                                  
###这里将以项目test4作为演示

JUnit  编写测试案例

	在项目test5里，有一个应用 POJO 类（没有任何规则约束的简单对象），Business logic 类和在 TestRunner 中运行的 test 类的 JUnit 测试。

##JUnit  使用断言
所有的断言都包含在 Assert 类中。

Assert类里提供了很多有用的断言方法来编写测试用例。只有失败的断言才会被记录。

Assert 类中的还有一些有用的方法列式如下(补充API的Assert 类部分):

void assertSame(boolean condition)  
检查两个相关对象是否指向同一对象

void assertNotSame(boolean condition)
检查两个相关对象是否不指向同一个对象

void assertArrayEquals(expectedArray, resultArray)
检查两个数组是否相等 

###这里将以项目test6作为补充演示

##JUnit  测试套件
在实际项目中，随着项目进度的开展，单元测试类会越来越多，可是直到现在我们还只会一个一个的单独运行测试类，这在实际项目实践中肯定是不可行的。为了解决这个问题，JUnit 提供了一种批量运行测试类的方法，叫做测试套件。
      这样，每次需要验证系统功能正确性时，只执行一个或几个测试套件便可以了。测试套件的写法非常简单，我们需要遵循以下规则：   
             
       1.创建一个空类作为测试套件的入口。  
           
       2.使用注解 org.junit.runner.RunWith 和 
           org.junit.runners.Suite.SuiteClasses 修饰这个空类。

       3.将 org.junit.runners.Suite 作为参数传入注解 RunWith，以提示 
           JUnit 为此类使用套件运行器执行。

       4.将需要放入此测试套件的测试类组成数组作为注解 SuiteClasses 的参数。

       5.保证该空类使用 public 修饰，而且存在公开的不带有任何参数的构造函数。

###这里将以项目test7作为演示

##JUnit  忽略测试

有时可能会发生我们的代码还没有准备好的情况，这时测试用例去测试这个方法或代码的时候会造成失败。
       @Ignore 注释会在这种情况时帮助我们：


        1. 一个含有 @Ignore 注释的测试方法将不会被执行；
        2. 如果一个测试类有 @Ignore 注释，则它的测试方法将不会执行；
        
这里我们用项目testignore来学习 @Ignore


##JUnit  时间测试
有Junit 提供了一个暂停的方便选项。如果一个测试用例比起指定的毫秒数花费了更多的时间，那么 Junit 将自动将它标记为失败。timeout 参数和 @Test 注释一起使用。

这里我们用项目testtime来学习 @test(timeout)


##JUnit  异常测试
Junit 用代码处理提供了一个追踪异常的选项。

      你可以测试代码是否它抛出了想要得到的异常。
      expected 参数和 @Test 注释一起使用。
      但我们期望得到一个异常却没有得到异常时，也会进行提示。
      这里我们用项目testexpected来学习@Test(expected)


##JUnit  参数化测试
参数化测试允许开发人员使用不同的值反复运行同一个测试。
       这将遵循 5 个步骤来创建参数化测试：

1. 用 @RunWith(Parameterized.class) 来注释 test 类。
2. 创建一个由 @Parameters 注释的公共的静态方法，它返回一个对象的集合               
(数组)来作为测试数据集合。
3. 创建一个公共的构造函数，它接受和一行测试数据相等同的东西。
4. 为每一列测试数据创建一个实例变量。
5. 用实例变量作为测试数据的来源来创建测试用例。
###这里将以项目testparameters作为演示

